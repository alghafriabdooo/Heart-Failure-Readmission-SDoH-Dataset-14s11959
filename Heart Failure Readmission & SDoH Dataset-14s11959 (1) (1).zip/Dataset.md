```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier

from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
```


```python
tree = pd.read_csv(r"C:\Users\14S11959\AppData\Roaming\Microsoft\Windows\Network Shortcuts\heart_failure_readmission_dataset.csv")
```


```python
# Step 3: View initial rows
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>patient_id</th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>sodium</th>
      <th>creatinine</th>
      <th>systolic_bp</th>
      <th>heart_rate</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12911</td>
      <td>76</td>
      <td>Male</td>
      <td>23.9</td>
      <td>738</td>
      <td>135.3</td>
      <td>1.58</td>
      <td>151</td>
      <td>93</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12521</td>
      <td>77</td>
      <td>Male</td>
      <td>32.3</td>
      <td>405</td>
      <td>143.0</td>
      <td>1.50</td>
      <td>107</td>
      <td>74</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10155</td>
      <td>42</td>
      <td>Male</td>
      <td>29.3</td>
      <td>399</td>
      <td>NaN</td>
      <td>1.43</td>
      <td>121</td>
      <td>97</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12088</td>
      <td>83</td>
      <td>Female</td>
      <td>29.1</td>
      <td>524</td>
      <td>135.1</td>
      <td>0.91</td>
      <td>114</td>
      <td>66</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10792</td>
      <td>48</td>
      <td>Female</td>
      <td>24.2</td>
      <td>301</td>
      <td>139.5</td>
      <td>0.54</td>
      <td>122</td>
      <td>79</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
null_summary = tree.isnull().sum()
print(null_summary)
```

    patient_id                  0
    age                         0
    gender                      0
    bmi                        90
    bnp                         0
    sodium                     90
    creatinine                 90
    systolic_bp                 0
    heart_rate                  0
    ace_inhibitor               0
    beta_blocker                0
    diuretic                    0
    adherence_score             0
    income_level                0
    distance_to_hospital_km     0
    readmitted_30d              0
    dtype: int64
    


```python
tree = tree.drop(columns=['patient_id'])
```


```python
tree[['sodium','creatinine']] = tree[['sodium','creatinine']].apply(pd.to_datetime, errors='coerce')
tree['calculation'] = (tree['creatinine'] - tree['sodium']).dt.days
```


```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>sodium</th>
      <th>creatinine</th>
      <th>systolic_bp</th>
      <th>heart_rate</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>Male</td>
      <td>23.9</td>
      <td>738</td>
      <td>1970-01-01 00:00:00.000000135</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>151</td>
      <td>93</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>Male</td>
      <td>32.3</td>
      <td>405</td>
      <td>1970-01-01 00:00:00.000000143</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>107</td>
      <td>74</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>Male</td>
      <td>29.3</td>
      <td>399</td>
      <td>NaT</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>121</td>
      <td>97</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>Female</td>
      <td>29.1</td>
      <td>524</td>
      <td>1970-01-01 00:00:00.000000135</td>
      <td>1970-01-01 00:00:00.000000000</td>
      <td>114</td>
      <td>66</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>Female</td>
      <td>24.2</td>
      <td>301</td>
      <td>1970-01-01 00:00:00.000000139</td>
      <td>1970-01-01 00:00:00.000000000</td>
      <td>122</td>
      <td>79</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
tree = tree.drop(columns=['sodium', 'creatinine'])
```


```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>systolic_bp</th>
      <th>heart_rate</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>Male</td>
      <td>23.9</td>
      <td>738</td>
      <td>151</td>
      <td>93</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>Male</td>
      <td>32.3</td>
      <td>405</td>
      <td>107</td>
      <td>74</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>Male</td>
      <td>29.3</td>
      <td>399</td>
      <td>121</td>
      <td>97</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>Female</td>
      <td>29.1</td>
      <td>524</td>
      <td>114</td>
      <td>66</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>Female</td>
      <td>24.2</td>
      <td>301</td>
      <td>122</td>
      <td>79</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
tree = tree.drop(columns=['systolic_bp', 'heart_rate'])
```


```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>Male</td>
      <td>23.9</td>
      <td>738</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>Male</td>
      <td>32.3</td>
      <td>405</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>Male</td>
      <td>29.3</td>
      <td>399</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>Female</td>
      <td>29.1</td>
      <td>524</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>Female</td>
      <td>24.2</td>
      <td>301</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
gender_map = {'Male': 0, 'M': 0, 'male': 0, 
              'Female': 1, 'F': 1, 'female': 1}
tree['gender'] = tree['gender'].map(gender_map)
```


```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>0</td>
      <td>23.9</td>
      <td>738</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>0</td>
      <td>32.3</td>
      <td>405</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>0</td>
      <td>29.3</td>
      <td>399</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>1</td>
      <td>29.1</td>
      <td>524</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>1</td>
      <td>24.2</td>
      <td>301</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
tree['bmi'].nunique()
tree['bmi'].unique()
```




    array([23.9, 32.3, 29.3, 29.1, 24.2, 30.1, 30.7, 33.7, 28.2, 23.2, 27.5,
           33.9, 30.6, 23.7, 23. , 27.9, 30. , 27.8, 27.3,  nan, 28.1, 21.1,
           26.2, 27. , 36.8, 31.1, 31.8, 38. , 20. , 27.6, 37.4, 34.8, 22.7,
           21.3, 35.3, 24.3, 28.9, 38.1, 36.2, 31.9, 25.7, 22.3, 29.8, 25.6,
           29.9, 27.4, 20.8, 25.8, 24.1, 32. , 30.3, 34.6, 35.6, 32.6, 37.1,
           32.5, 35.7, 23.6, 27.7, 20.6, 26.1, 40.3, 32.1, 26.6, 19.6, 37.5,
           27.1, 25.2, 22.4, 26.9, 24.4, 23.5, 22.8, 29. , 26.7, 28.7, 36.4,
           20.5, 31.7, 30.5, 19.9, 24.7, 21.7, 36.5, 22.1, 31.6, 35. , 23.3,
           26.5, 19.4, 33.1, 24.9, 20.1, 24. , 36.9, 37.6, 31.4, 26.4, 17. ,
           31.3, 33.4, 26.3, 25.4, 38.3, 22.2, 25. , 23.8, 19.5, 39.3, 18.1,
           18.9, 32.2, 32.8, 36.7, 34.7, 28.4, 32.7, 23.4, 20.4, 37.2, 28.8,
           34. , 25.5, 28.5, 34.5, 29.6, 22.5, 20.7, 24.5, 16.5, 18.3, 34.9,
           37.7, 31.2, 30.8, 27.2, 25.9, 33.6, 35.9, 15.8, 33.2, 21. , 29.4,
           18.8, 30.9, 28.6, 36. , 36.1, 18.6, 31.5, 23.1, 36.3, 26.8, 32.9,
           18.5, 22. , 41.9, 30.4, 21.9, 37.3, 26. , 22.9, 35.2, 40.8, 19.3,
           33.5, 28. , 21.6, 38.8, 20.2, 39.9, 24.8, 19.8, 38.7, 25.3, 19.2,
           24.6, 38.6, 31. , 25.1, 21.2, 18.2, 35.8, 34.4, 33. , 13.5, 17.9,
           17.1, 32.4, 17.5, 21.8, 28.3, 33.3, 19.7, 35.4, 40.7, 15.7, 39. ,
           16.1, 29.7, 29.5, 19.1, 29.2, 17.8, 37.9, 30.2, 37. , 21.4, 18.4,
           33.8, 40.5, 38.9, 16.3, 38.2, 22.6, 16.9, 19. , 12.9, 13.8, 11.5,
           20.9, 42.8, 34.3, 37.8, 40.1, 35.1, 14.8, 16.6, 17.2, 38.4, 35.5,
           16. , 39.2, 34.2, 14.5, 17.7, 18. , 42.7, 34.1, 39.5, 15.9, 39.6,
           21.5, 36.6, 18.7, 15. , 16.2, 16.7, 38.5, 12.5, 14.7, 17.6, 20.3,
           17.3, 39.7, 15.5, 39.4, 44.9, 40.4,  8.8, 14.3, 16.8, 15.3, 39.8,
           15.1])




```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>0</td>
      <td>23.9</td>
      <td>738</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>0</td>
      <td>32.3</td>
      <td>405</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>0</td>
      <td>29.3</td>
      <td>399</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>1</td>
      <td>29.1</td>
      <td>524</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>1</td>
      <td>24.2</td>
      <td>301</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(tree.columns.tolist())
```

    ['age', 'gender', 'bmi', 'bnp', 'ace_inhibitor', 'beta_blocker', 'diuretic', 'adherence_score', 'income_level', 'distance_to_hospital_km', 'readmitted_30d', 'calculation']
    


```python
print(tree['income_level'].unique())
print(tree['income_level'].str.len().unique())  # length of strings
```

    ['Medium' 'Low' 'High']
    [6 3 4]
    


```python
from sklearn.preprocessing import LabelEncoder

# Initialize encoder
le = LabelEncoder()

# Fit and transform
tree['income level'] = le.fit_transform(tree['income_level'])

# Show mapping
print(dict(zip(le.classes_, le.transform(le.classes_))))
```

    {'High': 0, 'Low': 1, 'Medium': 2}
    


```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>ace_inhibitor</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>income_level</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
      <th>income level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>0</td>
      <td>23.9</td>
      <td>738</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>Medium</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>0</td>
      <td>32.3</td>
      <td>405</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>Medium</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>0</td>
      <td>29.3</td>
      <td>399</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>Low</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>1</td>
      <td>29.1</td>
      <td>524</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>Low</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>1</td>
      <td>24.2</td>
      <td>301</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>High</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()

# Encoding the column
tree['income level'] = le.fit_transform(tree['income_level'])

# Dropping the original column
tree.drop(columns=['income_level'], inplace=True)

print(tree.head())
```

       age  gender   bmi  bnp  beta_blocker  diuretic  adherence_score  \
    0   76       0  23.9  738             1         0             0.98   
    1   77       0  32.3  405             0         1             0.66   
    2   42       0  29.3  399             0         1             0.93   
    3   83       1  29.1  524             1         1             0.54   
    4   48       1  24.2  301             1         1             0.78   
    
       distance_to_hospital_km  readmitted_30d  calculation  income level  \
    0                     12.4               0         -1.0             2   
    1                     38.8               1         -1.0             2   
    2                     43.5               1          NaN             1   
    3                     33.3               1         -1.0             1   
    4                     21.3               0         -1.0             0   
    
       ace inhibitor  income-level  
    0              1             2  
    1              1             2  
    2              1             1  
    3              0             1  
    4              1             0  
    


```python
negatives = (tree < 1).any()

print("Columns with negative values:")
print(negatives[negatives == True])
```

    Columns with negative values:
    gender             True
    beta_blocker       True
    diuretic           True
    adherence_score    True
    readmitted_30d     True
    calculation        True
    income level       True
    ace inhibitor      True
    income-level       True
    dtype: bool
    


```python
print("Number of negative adherence score:", (tree['adherence_score'] < 0).sum())
```

    Number of negative adherence score: 0
    


```python
# 1. Save the negative Billing Amount records separately
refund_records = tree[tree['adherence_score'] < 0].copy()

# Optional: save to CSV for future use
refund_records.to_csv('heart_failure_readmission_dataset.csv', index=False)

# 2. Create a new dataset without negative Billing Amounts for modeling
tree_clean = tree[tree['adherence_score'] >= 0].copy()


# 3. Verify
print("Original dataset size:", tree.shape[0])
print("Refund records size:", refund_records.shape[0])
print("Clean dataset size:", tree_clean.shape[0])
```

    Original dataset size: 3000
    Refund records size: 0
    Clean dataset size: 3000
    


```python
tree_clean.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
      <th>income level</th>
      <th>ace inhibitor</th>
      <th>income-level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>0</td>
      <td>23.9</td>
      <td>738</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>0</td>
      <td>32.3</td>
      <td>405</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>0</td>
      <td>29.3</td>
      <td>399</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>1</td>
      <td>29.1</td>
      <td>524</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>1</td>
      <td>24.2</td>
      <td>301</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns
import matplotlib.pyplot as plt

# Compute correlation matrix
corr = tree_clean.corr()

# Correlation with target
print(corr['adherence_score'].sort_values(ascending=False))

# Optional: visualize entire correlation matrix
plt.figure(figsize=(12,8))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm")
plt.show()
```

    adherence_score            1.000000
    diuretic                   0.017098
    ace inhibitor              0.009320
    beta_blocker               0.009256
    age                        0.003493
    gender                    -0.001735
    distance_to_hospital_km   -0.005856
    income level              -0.008473
    income-level              -0.008473
    bnp                       -0.030880
    bmi                       -0.038911
    readmitted_30d            -0.193732
    calculation                     NaN
    Name: adherence_score, dtype: float64
    


    
![png](output_24_1.png)
    



```python
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()

# Encoding the column
tree['adherence_score'] = le.fit_transform(tree['adherence_score'])

# Dropping the original column
tree.drop(columns=['adherence_score'], inplace=True)

print(tree.head())
```

       age  gender   bmi  bnp  beta_blocker  diuretic  distance_to_hospital_km  \
    0   76       0  23.9  738             1         0                     12.4   
    1   77       0  32.3  405             0         1                     38.8   
    2   42       0  29.3  399             0         1                     43.5   
    3   83       1  29.1  524             1         1                     33.3   
    4   48       1  24.2  301             1         1                     21.3   
    
       readmitted_30d  calculation  income level  ace inhibitor  income-level  
    0               0         -1.0             2              1             2  
    1               1         -1.0             2              1             2  
    2               1          NaN             1              1             1  
    3               1         -1.0             1              0             1  
    4               0         -1.0             0              1             0  
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Histogram
plt.figure(figsize=(8,5))
sns.histplot(tree_clean['age'], bins=20, kde=True)
plt.title('age Distribution')
plt.xlabel('age')
plt.ylabel('Count')
plt.show()

# Optional: descriptive stats
print(tree_clean['age'].describe())
```


    
![png](output_26_0.png)
    


    count    3000.000000
    mean       65.254333
    std        14.806465
    min        40.000000
    25%        52.000000
    50%        65.000000
    75%        78.000000
    max        90.000000
    Name: age, dtype: float64
    


```python
tree_clean['age_group'] = pd.cut(
    tree_clean['age'],
    bins=[0, 18, 35, 52, 68, 100],
    labels=False
)

# Check distribution in each bucket
print(tree_clean['age_group'].value_counts().sort_index())
```

    2     778
    3     878
    4    1344
    Name: age_group, dtype: int64
    


```python
tree_clean.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>adherence_score</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
      <th>income level</th>
      <th>ace inhibitor</th>
      <th>income-level</th>
      <th>age_group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76</td>
      <td>0</td>
      <td>23.9</td>
      <td>738</td>
      <td>1</td>
      <td>0</td>
      <td>0.98</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77</td>
      <td>0</td>
      <td>32.3</td>
      <td>405</td>
      <td>0</td>
      <td>1</td>
      <td>0.66</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42</td>
      <td>0</td>
      <td>29.3</td>
      <td>399</td>
      <td>0</td>
      <td>1</td>
      <td>0.93</td>
      <td>43.5</td>
      <td>1</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>1</td>
      <td>29.1</td>
      <td>524</td>
      <td>1</td>
      <td>1</td>
      <td>0.54</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48</td>
      <td>1</td>
      <td>24.2</td>
      <td>301</td>
      <td>1</td>
      <td>1</td>
      <td>0.78</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Separate numeric and categorical columns
numeric_cols = tree.select_dtypes(include=[np.number]).columns.tolist()
if 'readmitted_30d' in numeric_cols:
    numeric_cols.remove('readmitted_30d') # Keep target isolated
   
categorical_cols = tree.select_dtypes(exclude=[np.number]).columns.tolist()

# 1. Fill numeric null values with the median
for col in numeric_cols:
    tree[col] = tree[col].fillna(tree[col].median())

# 2. Fill categorical null values with the mode
for col in categorical_cols:
    tree[col] = tree[col].fillna(tree[col].mode()[0])

print("Null values remaining:", tree.isnull().sum().sum())
```

    Null values remaining: 0
    


```python

# Cap outliers to prevent them from distorting KNN calculations
for col in numeric_cols:
    Q1 = tree[col].quantile(0.25)
    Q3 = tree[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
   
    # Winsorize/Cap the extreme values
    tree[col] = np.where(tree[col] < lower_bound, lower_bound, tree[col])
    tree[col] = np.where(tree[col] > upper_bound, upper_bound, tree[col])

print("Outliers capped successfully across numerical columns.")
```

    Outliers capped successfully across numerical columns.
    


```python
from sklearn.model_selection import train_test_split

# Encode categorical variables into numeric dummy columns
tree_encoded = pd.get_dummies(tree, columns=categorical_cols, drop_first=True)

# Separate features (X) and target label (y)
X = tree_encoded.drop(columns=['readmitted_30d'])
y = tree_encoded['readmitted_30d']

# Split into 80% Training and 20% Testing sets
X_train_raw, X_test_raw, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

# Create copies specific to KNN to preserve pure data structures
X_train_scaled = scaler.fit_transform(X_train_raw)
X_test_scaled = scaler.transform(X_test_raw)

# Convert back to dataframes/arrays for structural safety
X_train_dt, X_test_dt = X_train_raw.copy(), X_test_raw.copy()
```


```python
from sklearn.tree import DecisionTreeClassifier
from sklearn.impute import SimpleImputer

# Handle missing values using mean
imputer = SimpleImputer(strategy='mean')

X_train = imputer.fit_transform(X_train)
X_test = imputer.transform(X_test)

# Initialize Decision Tree model
dt_model = DecisionTreeClassifier(max_depth=5, random_state=42)

# Train the model
dt_model.fit(X_train, y_train)

# Make predictions
y_pred = dt_model.predict(X_test)

print(y_pred)
```

    [0 0 0 0 0 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 0 1 0 1 0 0 1 0 1 0 1 1 1 0 1 0 1
     0 0 1 0 1 0 1 0 0 0 1 0 0 0 0 0 0 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 1
     0 1 0 0 0 0 0 0 0 0 0 1 1 1 1 0 0 1 0 1 0 0 1 0 0 0 0 1 0 0 0 1 0 1 0 1 0
     1 1 0 0 1 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 1 0 1 1 0 0 0 0 0 0 1 0 1 0 0 0
     0 0 1 0 0 1 0 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 1 1 0 0 0 0 0 1 0 0 0 0 0 0
     0 0 0 1 1 0 0 1 1 1 0 0 0 0 0 1 0 1 0 0 1 0 0 1 0 0 0 1 1 0 0 1 1 1 0 0 0
     0 1 1 0 1 1 1 0 1 0 1 1 1 1 0 0 0 1 0 1 1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 1 1
     0 0 0 1 0 1 0 1 1 0 0 0 0 0 1 0 1 0 0 0 1 0 0 0 1 1 0 1 1 0 0 0 1 0 0 1 1
     0 0 1 0 1 1 0 0 0 0 1 0 0 0 0 0 0 0 1 1 0 1 1 0 1 0 1 0 0 0 1 1 1 0 0 1 0
     0 1 0 0 0 1 0 1 1 1 0 0 0 1 0 0 0 0 1 1 0 0 1 0 0 0 1 1 1 1 1 1 0 0 0 0 0
     1 0 0 0 0 1 1 1 0 0 0 0 0 0 0 1 0 1 1 0 1 0 1 0 1 0 0 0 1 0 1 0 1 0 0 0 1
     0 0 1 0 1 1 0 0 0 0 1 0 1 1 0 1 0 0 1 0 0 0 1 0 0 1 0 0 0 0 0 0 0 1 1 1 1
     0 0 0 1 0 0 0 0 0 1 0 0 1 1 1 0 0 0 0 0 1 0 0 0 0 1 1 1 0 1 1 1 1 1 0 0 0
     0 0 0 1 0 0 0 1 1 0 0 0 0 1 0 1 0 1 0 0 1 1 0 0 1 1 0 1 1 0 0 1 0 1 1 0 1
     0 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 0 0 1 0 1 0 0 0 0 0 1 0 0
     0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 1 0 0 0 0 1 0 1 1 0 0 0 0 1 0 0 1 1 1 0 0 0
     0 1 1 0 1 0 1 1]
    


```python
# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

```


```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

# Create copies specific to KNN to preserve pure data structures
X_train_scaled = scaler.fit_transform(X_train_raw)
X_test_scaled = scaler.transform(X_test_raw)

# Convert back to dataframes/arrays for structural safety
X_train_dt, X_test_dt = X_train_raw.copy(), X_test_raw.copy()
```


```python
# Step 17: List current columns
print(tree.columns.tolist())
```

    ['age', 'gender', 'bmi', 'bnp', 'beta_blocker', 'diuretic', 'distance_to_hospital_km', 'readmitted_30d', 'calculation', 'income level', 'ace inhibitor', 'income-level']
    


```python
fig, ax = plt.subplots(1, 2, figsize=(14, 5))

# Decision Tree Confusion Matrix
dt_cm = confusion_matrix(y_test, dt_preds)
sns.heatmap(dt_cm, annot=True, fmt='d', cmap='Blues', ax=ax[0])
ax[0].set_title('Decision Tree Confusion Matrix')
ax[0].set_xlabel('Predicted Label')
ax[0].set_ylabel('True Label')

# KNN Confusion Matrix
knn_cm = confusion_matrix(y_test, knn_preds)
sns.heatmap(knn_cm, annot=True, fmt='d', cmap='Greens', ax=ax[1])
ax[1].set_title('KNN Confusion Matrix')
ax[1].set_xlabel('Predicted Label')
ax[1].set_ylabel('True Label')

plt.tight_layout()
plt.show()
```


    
![png](output_37_0.png)
    



```python
# Step 27: Check if variables like distance or bnp have anomalies (Replacing Billing Amount logic)
print("Number of negative distances:", (tree['distance_to_hospital_km'] < 0).sum())
```

    Number of negative distances: 0
    


```python
# Step 28 & 29: Filter out any anomalous rows if they exist, create clean dataset
# (Adapting 'Billing Amount' filtering to 'distance_to_hospital_km')
anomalous_records = tree[tree['distance_to_hospital_km'] < 0].copy()
tree_clean = tree[tree['distance_to_hospital_km'] >= 0].copy()
```


```python
print("Original dataset size:", tree.shape[0])
print("Clean dataset size:", tree_clean.shape[0])
print(tree_clean.head())
```

    Original dataset size: 3000
    Clean dataset size: 3000
        age  gender   bmi    bnp  beta_blocker  diuretic  distance_to_hospital_km  \
    0  76.0     0.0  23.9  738.0           1.0       0.0                     12.4   
    1  77.0     0.0  32.3  405.0           0.0       1.0                     38.8   
    2  42.0     0.0  29.3  399.0           0.0       1.0                     43.5   
    3  83.0     1.0  29.1  524.0           1.0       1.0                     33.3   
    4  48.0     1.0  24.2  301.0           1.0       1.0                     21.3   
    
       readmitted_30d  calculation  income level  ace inhibitor  income-level  
    0               0         -1.0           2.0            1.0           2.0  
    1               1         -1.0           2.0            1.0           2.0  
    2               1         -1.0           1.0            1.0           1.0  
    3               1         -1.0           1.0            0.0           1.0  
    4               0         -1.0           0.0            1.0           0.0  
    


```python
from sklearn.preprocessing import LabelEncoder

# List of categorical columns
cat_cols = [ 'age', 'bmi', 'bnp']

# Apply Label Encoding to each column
for col in cat_cols:
    le = LabelEncoder()
    tree[col + '_encoded'] = le.fit_transform(tree[col])
    print(f"{col} mapping:", dict(zip(le.classes_, le.transform(le.classes_))))
```

    age mapping: {40.0: 0, 41.0: 1, 42.0: 2, 43.0: 3, 44.0: 4, 45.0: 5, 46.0: 6, 47.0: 7, 48.0: 8, 49.0: 9, 50.0: 10, 51.0: 11, 52.0: 12, 53.0: 13, 54.0: 14, 55.0: 15, 56.0: 16, 57.0: 17, 58.0: 18, 59.0: 19, 60.0: 20, 61.0: 21, 62.0: 22, 63.0: 23, 64.0: 24, 65.0: 25, 66.0: 26, 67.0: 27, 68.0: 28, 69.0: 29, 70.0: 30, 71.0: 31, 72.0: 32, 73.0: 33, 74.0: 34, 75.0: 35, 76.0: 36, 77.0: 37, 78.0: 38, 79.0: 39, 80.0: 40, 81.0: 41, 82.0: 42, 83.0: 43, 84.0: 44, 85.0: 45, 86.0: 46, 87.0: 47, 88.0: 48, 89.0: 49, 90.0: 50}
    bmi mapping: {15.149999999999999: 0, 15.3: 1, 15.5: 2, 15.7: 3, 15.8: 4, 15.9: 5, 16.0: 6, 16.1: 7, 16.2: 8, 16.3: 9, 16.5: 10, 16.6: 11, 16.7: 12, 16.8: 13, 16.9: 14, 17.0: 15, 17.1: 16, 17.2: 17, 17.3: 18, 17.5: 19, 17.6: 20, 17.7: 21, 17.8: 22, 17.9: 23, 18.0: 24, 18.1: 25, 18.2: 26, 18.3: 27, 18.4: 28, 18.5: 29, 18.6: 30, 18.7: 31, 18.8: 32, 18.9: 33, 19.0: 34, 19.1: 35, 19.2: 36, 19.3: 37, 19.4: 38, 19.5: 39, 19.6: 40, 19.7: 41, 19.8: 42, 19.9: 43, 20.0: 44, 20.1: 45, 20.2: 46, 20.3: 47, 20.4: 48, 20.5: 49, 20.6: 50, 20.7: 51, 20.8: 52, 20.9: 53, 21.0: 54, 21.1: 55, 21.2: 56, 21.3: 57, 21.4: 58, 21.5: 59, 21.6: 60, 21.7: 61, 21.8: 62, 21.9: 63, 22.0: 64, 22.1: 65, 22.2: 66, 22.3: 67, 22.4: 68, 22.5: 69, 22.6: 70, 22.7: 71, 22.8: 72, 22.9: 73, 23.0: 74, 23.1: 75, 23.2: 76, 23.3: 77, 23.4: 78, 23.5: 79, 23.6: 80, 23.7: 81, 23.8: 82, 23.9: 83, 24.0: 84, 24.1: 85, 24.2: 86, 24.3: 87, 24.4: 88, 24.5: 89, 24.6: 90, 24.7: 91, 24.8: 92, 24.9: 93, 25.0: 94, 25.1: 95, 25.2: 96, 25.3: 97, 25.4: 98, 25.5: 99, 25.6: 100, 25.7: 101, 25.8: 102, 25.9: 103, 26.0: 104, 26.1: 105, 26.2: 106, 26.3: 107, 26.4: 108, 26.5: 109, 26.6: 110, 26.7: 111, 26.8: 112, 26.9: 113, 27.0: 114, 27.1: 115, 27.2: 116, 27.3: 117, 27.4: 118, 27.5: 119, 27.6: 120, 27.7: 121, 27.8: 122, 27.9: 123, 28.0: 124, 28.1: 125, 28.2: 126, 28.3: 127, 28.4: 128, 28.5: 129, 28.6: 130, 28.7: 131, 28.8: 132, 28.9: 133, 29.0: 134, 29.1: 135, 29.2: 136, 29.3: 137, 29.4: 138, 29.5: 139, 29.6: 140, 29.7: 141, 29.8: 142, 29.9: 143, 30.0: 144, 30.1: 145, 30.2: 146, 30.3: 147, 30.4: 148, 30.5: 149, 30.6: 150, 30.7: 151, 30.8: 152, 30.9: 153, 31.0: 154, 31.1: 155, 31.2: 156, 31.3: 157, 31.4: 158, 31.5: 159, 31.6: 160, 31.7: 161, 31.8: 162, 31.9: 163, 32.0: 164, 32.1: 165, 32.2: 166, 32.3: 167, 32.4: 168, 32.5: 169, 32.6: 170, 32.7: 171, 32.8: 172, 32.9: 173, 33.0: 174, 33.1: 175, 33.2: 176, 33.3: 177, 33.4: 178, 33.5: 179, 33.6: 180, 33.7: 181, 33.8: 182, 33.9: 183, 34.0: 184, 34.1: 185, 34.2: 186, 34.3: 187, 34.4: 188, 34.5: 189, 34.6: 190, 34.7: 191, 34.8: 192, 34.9: 193, 35.0: 194, 35.1: 195, 35.2: 196, 35.3: 197, 35.4: 198, 35.5: 199, 35.6: 200, 35.7: 201, 35.8: 202, 35.9: 203, 36.0: 204, 36.1: 205, 36.2: 206, 36.3: 207, 36.4: 208, 36.5: 209, 36.6: 210, 36.7: 211, 36.8: 212, 36.9: 213, 37.0: 214, 37.1: 215, 37.2: 216, 37.3: 217, 37.4: 218, 37.5: 219, 37.6: 220, 37.7: 221, 37.8: 222, 37.9: 223, 38.0: 224, 38.1: 225, 38.2: 226, 38.3: 227, 38.4: 228, 38.5: 229, 38.6: 230, 38.7: 231, 38.8: 232, 38.9: 233, 39.0: 234, 39.2: 235, 39.3: 236, 39.4: 237, 39.5: 238, 39.6: 239, 39.7: 240, 39.8: 241, 39.9: 242, 40.1: 243, 40.3: 244, 40.4: 245, 40.5: 246, 40.7: 247, 40.8: 248, 41.15: 249}
    bnp mapping: {50.0: 0, 51.0: 1, 52.0: 2, 54.0: 3, 55.0: 4, 56.0: 5, 57.0: 6, 58.0: 7, 59.0: 8, 60.0: 9, 61.0: 10, 62.0: 11, 64.0: 12, 65.0: 13, 66.0: 14, 67.0: 15, 69.0: 16, 71.0: 17, 72.0: 18, 74.0: 19, 75.0: 20, 76.0: 21, 77.0: 22, 78.0: 23, 79.0: 24, 80.0: 25, 81.0: 26, 82.0: 27, 83.0: 28, 84.0: 29, 85.0: 30, 86.0: 31, 87.0: 32, 88.0: 33, 89.0: 34, 90.0: 35, 91.0: 36, 92.0: 37, 93.0: 38, 94.0: 39, 95.0: 40, 96.0: 41, 97.0: 42, 98.0: 43, 99.0: 44, 101.0: 45, 102.0: 46, 103.0: 47, 104.0: 48, 105.0: 49, 106.0: 50, 107.0: 51, 110.0: 52, 112.0: 53, 113.0: 54, 114.0: 55, 115.0: 56, 116.0: 57, 117.0: 58, 118.0: 59, 119.0: 60, 120.0: 61, 121.0: 62, 122.0: 63, 123.0: 64, 124.0: 65, 125.0: 66, 126.0: 67, 127.0: 68, 128.0: 69, 129.0: 70, 130.0: 71, 131.0: 72, 132.0: 73, 133.0: 74, 134.0: 75, 135.0: 76, 136.0: 77, 137.0: 78, 138.0: 79, 139.0: 80, 140.0: 81, 141.0: 82, 143.0: 83, 144.0: 84, 145.0: 85, 146.0: 86, 148.0: 87, 149.0: 88, 150.0: 89, 151.0: 90, 152.0: 91, 153.0: 92, 154.0: 93, 155.0: 94, 156.0: 95, 157.0: 96, 158.0: 97, 159.0: 98, 160.0: 99, 161.0: 100, 162.0: 101, 163.0: 102, 164.0: 103, 165.0: 104, 167.0: 105, 168.0: 106, 169.0: 107, 170.0: 108, 171.0: 109, 172.0: 110, 173.0: 111, 174.0: 112, 175.0: 113, 176.0: 114, 177.0: 115, 178.0: 116, 179.0: 117, 180.0: 118, 181.0: 119, 182.0: 120, 183.0: 121, 184.0: 122, 185.0: 123, 186.0: 124, 187.0: 125, 188.0: 126, 189.0: 127, 190.0: 128, 191.0: 129, 192.0: 130, 193.0: 131, 194.0: 132, 195.0: 133, 196.0: 134, 197.0: 135, 198.0: 136, 199.0: 137, 200.0: 138, 201.0: 139, 202.0: 140, 203.0: 141, 204.0: 142, 205.0: 143, 206.0: 144, 207.0: 145, 208.0: 146, 209.0: 147, 210.0: 148, 211.0: 149, 212.0: 150, 213.0: 151, 214.0: 152, 215.0: 153, 216.0: 154, 217.0: 155, 218.0: 156, 219.0: 157, 220.0: 158, 221.0: 159, 222.0: 160, 223.0: 161, 224.0: 162, 225.0: 163, 226.0: 164, 227.0: 165, 228.0: 166, 229.0: 167, 230.0: 168, 231.0: 169, 232.0: 170, 233.0: 171, 234.0: 172, 235.0: 173, 236.0: 174, 237.0: 175, 238.0: 176, 239.0: 177, 240.0: 178, 241.0: 179, 242.0: 180, 243.0: 181, 244.0: 182, 245.0: 183, 246.0: 184, 247.0: 185, 248.0: 186, 249.0: 187, 250.0: 188, 251.0: 189, 252.0: 190, 254.0: 191, 255.0: 192, 256.0: 193, 257.0: 194, 258.0: 195, 259.0: 196, 260.0: 197, 261.0: 198, 262.0: 199, 263.0: 200, 264.0: 201, 265.0: 202, 266.0: 203, 267.0: 204, 268.0: 205, 269.0: 206, 270.0: 207, 271.0: 208, 272.0: 209, 273.0: 210, 274.0: 211, 275.0: 212, 276.0: 213, 277.0: 214, 278.0: 215, 279.0: 216, 280.0: 217, 281.0: 218, 282.0: 219, 283.0: 220, 284.0: 221, 285.0: 222, 286.0: 223, 287.0: 224, 288.0: 225, 289.0: 226, 290.0: 227, 291.0: 228, 292.0: 229, 293.0: 230, 294.0: 231, 295.0: 232, 296.0: 233, 297.0: 234, 298.0: 235, 299.0: 236, 300.0: 237, 301.0: 238, 302.0: 239, 303.0: 240, 304.0: 241, 305.0: 242, 306.0: 243, 307.0: 244, 308.0: 245, 309.0: 246, 310.0: 247, 311.0: 248, 312.0: 249, 313.0: 250, 314.0: 251, 315.0: 252, 316.0: 253, 317.0: 254, 318.0: 255, 319.0: 256, 320.0: 257, 321.0: 258, 322.0: 259, 323.0: 260, 324.0: 261, 325.0: 262, 326.0: 263, 327.0: 264, 328.0: 265, 329.0: 266, 330.0: 267, 331.0: 268, 332.0: 269, 333.0: 270, 334.0: 271, 335.0: 272, 336.0: 273, 337.0: 274, 338.0: 275, 339.0: 276, 340.0: 277, 341.0: 278, 342.0: 279, 343.0: 280, 344.0: 281, 345.0: 282, 346.0: 283, 347.0: 284, 348.0: 285, 349.0: 286, 350.0: 287, 351.0: 288, 352.0: 289, 353.0: 290, 354.0: 291, 355.0: 292, 356.0: 293, 357.0: 294, 358.0: 295, 359.0: 296, 360.0: 297, 361.0: 298, 362.0: 299, 363.0: 300, 364.0: 301, 365.0: 302, 366.0: 303, 367.0: 304, 368.0: 305, 369.0: 306, 370.0: 307, 371.0: 308, 372.0: 309, 373.0: 310, 374.0: 311, 375.0: 312, 376.0: 313, 377.0: 314, 378.0: 315, 379.0: 316, 380.0: 317, 381.0: 318, 382.0: 319, 383.0: 320, 384.0: 321, 385.0: 322, 386.0: 323, 387.0: 324, 388.0: 325, 389.0: 326, 390.0: 327, 391.0: 328, 392.0: 329, 393.0: 330, 394.0: 331, 395.0: 332, 396.0: 333, 397.0: 334, 398.0: 335, 399.0: 336, 400.0: 337, 401.0: 338, 402.0: 339, 403.0: 340, 404.0: 341, 405.0: 342, 406.0: 343, 407.0: 344, 408.0: 345, 409.0: 346, 410.0: 347, 411.0: 348, 412.0: 349, 413.0: 350, 414.0: 351, 415.0: 352, 416.0: 353, 417.0: 354, 418.0: 355, 419.0: 356, 420.0: 357, 421.0: 358, 422.0: 359, 423.0: 360, 424.0: 361, 425.0: 362, 426.0: 363, 427.0: 364, 428.0: 365, 429.0: 366, 430.0: 367, 432.0: 368, 433.0: 369, 434.0: 370, 435.0: 371, 436.0: 372, 437.0: 373, 438.0: 374, 439.0: 375, 440.0: 376, 441.0: 377, 442.0: 378, 444.0: 379, 445.0: 380, 446.0: 381, 447.0: 382, 448.0: 383, 449.0: 384, 450.0: 385, 451.0: 386, 452.0: 387, 453.0: 388, 454.0: 389, 455.0: 390, 456.0: 391, 457.0: 392, 458.0: 393, 459.0: 394, 460.0: 395, 461.0: 396, 462.0: 397, 463.0: 398, 464.0: 399, 465.0: 400, 466.0: 401, 467.0: 402, 468.0: 403, 469.0: 404, 470.0: 405, 471.0: 406, 472.0: 407, 473.0: 408, 474.0: 409, 475.0: 410, 476.0: 411, 477.0: 412, 478.0: 413, 479.0: 414, 480.0: 415, 481.0: 416, 482.0: 417, 483.0: 418, 484.0: 419, 485.0: 420, 486.0: 421, 487.0: 422, 488.0: 423, 489.0: 424, 490.0: 425, 491.0: 426, 492.0: 427, 493.0: 428, 494.0: 429, 495.0: 430, 496.0: 431, 497.0: 432, 498.0: 433, 499.0: 434, 500.0: 435, 501.0: 436, 502.0: 437, 503.0: 438, 504.0: 439, 505.0: 440, 506.0: 441, 507.0: 442, 508.0: 443, 509.0: 444, 510.0: 445, 511.0: 446, 512.0: 447, 513.0: 448, 514.0: 449, 515.0: 450, 516.0: 451, 517.0: 452, 518.0: 453, 519.0: 454, 520.0: 455, 521.0: 456, 522.0: 457, 524.0: 458, 525.0: 459, 526.0: 460, 527.0: 461, 528.0: 462, 529.0: 463, 530.0: 464, 531.0: 465, 532.0: 466, 533.0: 467, 534.0: 468, 535.0: 469, 536.0: 470, 537.0: 471, 538.0: 472, 539.0: 473, 540.0: 474, 541.0: 475, 542.0: 476, 543.0: 477, 544.0: 478, 545.0: 479, 546.0: 480, 547.0: 481, 548.0: 482, 549.0: 483, 550.0: 484, 551.0: 485, 552.0: 486, 553.0: 487, 554.0: 488, 555.0: 489, 556.0: 490, 557.0: 491, 558.0: 492, 559.0: 493, 560.0: 494, 561.0: 495, 562.0: 496, 563.0: 497, 564.0: 498, 565.0: 499, 566.0: 500, 567.0: 501, 568.0: 502, 569.0: 503, 570.0: 504, 571.0: 505, 572.0: 506, 573.0: 507, 574.0: 508, 575.0: 509, 576.0: 510, 577.0: 511, 578.0: 512, 579.0: 513, 580.0: 514, 581.0: 515, 582.0: 516, 583.0: 517, 584.0: 518, 585.0: 519, 586.0: 520, 587.0: 521, 588.0: 522, 589.0: 523, 590.0: 524, 591.0: 525, 592.0: 526, 593.0: 527, 594.0: 528, 595.0: 529, 596.0: 530, 597.0: 531, 598.0: 532, 599.0: 533, 600.0: 534, 601.0: 535, 602.0: 536, 603.0: 537, 604.0: 538, 605.0: 539, 606.0: 540, 607.0: 541, 608.0: 542, 609.0: 543, 610.0: 544, 611.0: 545, 612.0: 546, 613.0: 547, 614.0: 548, 615.0: 549, 616.0: 550, 617.0: 551, 618.0: 552, 619.0: 553, 620.0: 554, 621.0: 555, 622.0: 556, 623.0: 557, 624.0: 558, 625.0: 559, 626.0: 560, 627.0: 561, 628.0: 562, 629.0: 563, 630.0: 564, 631.0: 565, 632.0: 566, 633.0: 567, 634.0: 568, 636.0: 569, 637.0: 570, 638.0: 571, 639.0: 572, 640.0: 573, 641.0: 574, 642.0: 575, 643.0: 576, 644.0: 577, 645.0: 578, 647.0: 579, 648.0: 580, 649.0: 581, 650.0: 582, 651.0: 583, 652.0: 584, 653.0: 585, 655.0: 586, 656.0: 587, 657.0: 588, 658.0: 589, 659.0: 590, 660.0: 591, 661.0: 592, 662.0: 593, 663.0: 594, 664.0: 595, 665.0: 596, 666.0: 597, 667.0: 598, 668.0: 599, 670.0: 600, 671.0: 601, 672.0: 602, 673.0: 603, 674.0: 604, 675.0: 605, 676.0: 606, 677.0: 607, 678.0: 608, 679.0: 609, 680.0: 610, 681.0: 611, 682.0: 612, 683.0: 613, 684.0: 614, 685.0: 615, 686.0: 616, 687.0: 617, 688.0: 618, 689.0: 619, 690.0: 620, 691.0: 621, 692.0: 622, 693.0: 623, 694.0: 624, 695.0: 625, 696.0: 626, 697.0: 627, 699.0: 628, 700.0: 629, 701.0: 630, 703.0: 631, 705.0: 632, 706.0: 633, 707.0: 634, 708.0: 635, 709.0: 636, 711.0: 637, 712.0: 638, 713.0: 639, 714.0: 640, 715.0: 641, 716.0: 642, 717.0: 643, 718.0: 644, 719.0: 645, 720.0: 646, 721.0: 647, 723.0: 648, 724.0: 649, 725.0: 650, 726.0: 651, 727.0: 652, 728.0: 653, 729.0: 654, 731.0: 655, 732.0: 656, 733.0: 657, 734.0: 658, 735.0: 659, 736.0: 660, 737.0: 661, 738.0: 662, 740.0: 663, 741.0: 664, 742.0: 665, 743.0: 666, 744.0: 667, 745.0: 668, 746.0: 669, 747.0: 670, 748.0: 671, 749.0: 672, 750.0: 673, 752.0: 674, 753.0: 675, 754.0: 676, 755.0: 677, 756.0: 678, 757.0: 679, 758.0: 680, 760.0: 681, 761.0: 682, 763.0: 683, 765.0: 684, 766.0: 685, 769.0: 686, 771.0: 687, 772.0: 688, 774.0: 689, 775.0: 690, 776.0: 691, 777.0: 692, 779.0: 693, 781.0: 694, 782.0: 695, 783.0: 696, 784.0: 697, 785.0: 698, 790.0: 699, 791.0: 700, 792.0: 701, 794.0: 702, 796.0: 703, 797.0: 704, 799.0: 705, 800.0: 706, 801.0: 707, 802.0: 708, 803.0: 709, 805.0: 710, 807.0: 711, 808.0: 712, 809.0: 713, 812.0: 714, 813.0: 715, 815.0: 716, 816.0: 717, 818.0: 718, 819.0: 719, 820.0: 720, 821.0: 721, 823.0: 722, 824.0: 723, 825.0: 724, 827.0: 725, 828.0: 726, 831.0: 727, 832.0: 728, 836.0: 729, 838.0: 730, 839.0: 731, 840.0: 732, 841.0: 733, 843.0: 734, 844.0: 735, 845.0: 736, 850.0: 737, 851.0: 738, 853.0: 739, 854.0: 740, 855.0: 741, 857.0: 742, 858.0: 743, 860.0: 744, 863.0: 745, 864.0: 746, 865.0: 747, 866.0: 748, 867.0: 749, 868.0: 750, 869.0: 751, 870.0: 752, 871.0: 753, 873.0: 754, 874.0: 755, 875.0: 756, 879.0: 757, 881.0: 758, 882.0: 759, 883.0: 760, 887.0: 761, 888.0: 762, 892.0: 763, 893.0: 764, 895.0: 765, 896.0: 766, 897.0: 767, 898.0: 768, 899.0: 769, 900.0: 770, 902.0: 771, 905.0: 772, 909.0: 773, 911.0: 774, 912.0: 775, 913.0: 776, 914.0: 777, 919.0: 778, 924.0: 779, 928.0: 780, 929.0: 781, 930.0: 782, 931.0: 783, 933.0: 784, 940.0: 785, 946.0: 786, 947.0: 787, 948.0: 788, 964.0: 789, 973.0: 790, 986.0: 791, 987.0: 792, 990.0: 793, 998.0: 794, 999.0: 795, 1008.0: 796, 1009.0: 797, 1012.0: 798, 1015.0: 799, 1020.0: 800, 1024.0: 801, 1025.0: 802, 1035.0: 803, 1046.0: 804, 1047.0: 805, 1050.0: 806, 1070.0: 807, 1074.0: 808, 1078.0: 809, 1085.0: 810}
    


```python
tree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
      <th>income level</th>
      <th>ace inhibitor</th>
      <th>income-level</th>
      <th>age_encoded</th>
      <th>bmi_encoded</th>
      <th>bnp_encoded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76.0</td>
      <td>0.0</td>
      <td>23.9</td>
      <td>738.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>36</td>
      <td>83</td>
      <td>662</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77.0</td>
      <td>0.0</td>
      <td>32.3</td>
      <td>405.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>37</td>
      <td>167</td>
      <td>342</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42.0</td>
      <td>0.0</td>
      <td>29.3</td>
      <td>399.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>43.5</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2</td>
      <td>137</td>
      <td>336</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83.0</td>
      <td>1.0</td>
      <td>29.1</td>
      <td>524.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>43</td>
      <td>135</td>
      <td>458</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48.0</td>
      <td>1.0</td>
      <td>24.2</td>
      <td>301.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>8</td>
      <td>86</td>
      <td>238</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
import seaborn as sns

# Histogram
plt.figure(figsize=(8,5))
sns.histplot(tree_clean['age'], bins=20, kde=True)
plt.title('age Distribution')
plt.xlabel('age')
plt.ylabel('Count')
plt.show()

# Optional: descriptive stats
print(tree_clean['age'].describe())
```


    
![png](output_43_0.png)
    


    count    3000.000000
    mean       65.254333
    std        14.806465
    min        40.000000
    25%        52.000000
    50%        65.000000
    75%        78.000000
    max        90.000000
    Name: age, dtype: float64
    


```python
tree_clean['age_group'] = pd.cut(
    tree_clean['age'],
    bins=[0, 18, 35, 52, 68, 100],
    labels=False
)

# Check distribution in each bucket
print(tree_clean['age_group'].value_counts().sort_index())

```

    2     778
    3     878
    4    1344
    Name: age_group, dtype: int64
    


```python
tree_clean.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>gender</th>
      <th>bmi</th>
      <th>bnp</th>
      <th>beta_blocker</th>
      <th>diuretic</th>
      <th>distance_to_hospital_km</th>
      <th>readmitted_30d</th>
      <th>calculation</th>
      <th>income level</th>
      <th>ace inhibitor</th>
      <th>income-level</th>
      <th>age_group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76.0</td>
      <td>0.0</td>
      <td>23.9</td>
      <td>738.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>12.4</td>
      <td>0</td>
      <td>-1.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>77.0</td>
      <td>0.0</td>
      <td>32.3</td>
      <td>405.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>38.8</td>
      <td>1</td>
      <td>-1.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>42.0</td>
      <td>0.0</td>
      <td>29.3</td>
      <td>399.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>43.5</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>83.0</td>
      <td>1.0</td>
      <td>29.1</td>
      <td>524.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>33.3</td>
      <td>1</td>
      <td>-1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>48.0</td>
      <td>1.0</td>
      <td>24.2</td>
      <td>301.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>21.3</td>
      <td>0</td>
      <td>-1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
numeric_cols = tree.select_dtypes(include=[np.number]).columns.tolist()
if 'readmitted_30d' in numeric_cols:
    numeric_cols.remove('readmitted_30d')
categorical_cols = tree.select_dtypes(exclude=[np.number]).columns.tolist()
```


```python
for col in numeric_cols:
    tree[col] = tree[col].fillna(tree[col].median())
for col in categorical_cols:
    tree[col] = tree[col].fillna(tree[col].mode()[0])
```


```python
for col in numeric_cols:
    Q1 = tree[col].quantile(0.25)
    Q3 = tree[col].quantile(0.75)
    IQR = Q3 - Q1
    tree[col] = np.where(tree[col] < (Q1 - 1.5 * IQR), Q1 - 1.5 * IQR, tree[col])
    tree[col] = np.where(tree[col] > (Q3 + 1.5 * IQR), Q3 + 1.5 * IQR, tree[col])
```


```python
tree_encoded = pd.get_dummies(tree, columns=categorical_cols, drop_first=True)
```


```python
# Separate features and target
X = tree_encoded.drop(columns=['readmitted_30d'])
y = tree_encoded['readmitted_30d']

# Split dataset into 80% Train and 20% Test
X_train_raw, X_test_raw, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features ONLY for KNN (keeps DT completely unswayed)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_raw)
X_test_scaled = scaler.transform(X_test_raw)
```


```python
# --- Model A: Decision Tree Classifier ---
dt_model = DecisionTreeClassifier(max_depth=5, random_state=42)
dt_model.fit(X_train_raw, y_train)
dt_preds = dt_model.predict(X_test_raw)

# --- Model B: K-Nearest Neighbors Classifier ---
knn_model = KNeighborsClassifier(n_neighbors=5)
knn_model.fit(X_train_scaled, y_train)
knn_preds = knn_model.predict(X_test_scaled)
```


```python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report # Ensure this is imported

# --- Decision Tree Report ---
print("=========================================")
print("       DECISION TREE CLASSIFICATION REPORT")
print("=========================================")
print(classification_report(y_test, dt_preds, digits=4))

# --- KNN Report ---
print("\n=========================================")
print("          KNN CLASSIFICATION REPORT")
print("=========================================")
print(classification_report(y_test, knn_preds, digits=4))

# --- Feature Importance ---
# Since you used a Decision Tree (dt_model), we use that to plot feature importance.
# We extract the feature names from X_train_raw (or tree_encoded.drop columns).

features = X_train_raw.columns
importances = pd.Series(dt_model.feature_importances_, index=features)

importances.sort_values().plot(kind='barh', figsize=(10, 6), title='Feature Importance (Decision Tree)')
plt.show()
```

    =========================================
           DECISION TREE CLASSIFICATION REPORT
    =========================================
                  precision    recall  f1-score   support
    
               0     0.6747    0.7487    0.7098       374
               1     0.4919    0.4027    0.4428       226
    
        accuracy                         0.6183       600
       macro avg     0.5833    0.5757    0.5763       600
    weighted avg     0.6058    0.6183    0.6092       600
    
    
    =========================================
              KNN CLASSIFICATION REPORT
    =========================================
                  precision    recall  f1-score   support
    
               0     0.6719    0.6845    0.6781       374
               1     0.4612    0.4469    0.4539       226
    
        accuracy                         0.5950       600
       macro avg     0.5666    0.5657    0.5660       600
    weighted avg     0.5925    0.5950    0.5937       600
    
    


    
![png](output_52_1.png)
    



```python

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# --- 1. Prepare Features and Target ---
# 'tree' is your DataFrame. We switch the target to 'readmitted_30d' to fix the error.
features = [col for col in tree.columns if col != 'readmitted_30d']
X = tree[features]
y = tree['readmitted_30d']

# --- 2. Split Dataset ---
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# --- 3. Initialize Decision Tree Model ---
# Kept as 'tree_model' so it doesn't overwrite your 'tree' dataset variable
tree_model = DecisionTreeClassifier(
    max_depth=None,
    min_samples_split=2,
    min_samples_leaf=1,
    random_state=42
)

# --- 4. Train Model ---
tree_model.fit(X_train, y_train)

# --- 5. Make Predictions and Evaluate ---
tree_pred = tree_model.predict(X_test)

print(f"Decision Tree Accuracy: {accuracy_score(y_test, tree_pred):.4f}")
print("\nClassification Report:")
print(classification_report(y_test, tree_pred, digits=4))

# --- 6. Plot Tree (First 3 levels for clean readability) ---
plt.figure(figsize=(20, 10))
plot_tree(
    tree_model,
    feature_names=features,
    class_names=['Not Readmitted', 'Readmitted'], # Correct target categories
    filled=True,
    max_depth=3
)
plt.show()
```

    Decision Tree Accuracy: 0.5033
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0     0.6111    0.5588    0.5838       374
               1     0.3605    0.4115    0.3843       226
    
        accuracy                         0.5033       600
       macro avg     0.4858    0.4852    0.4840       600
    weighted avg     0.5167    0.5033    0.5087       600
    
    


    
![png](output_53_1.png)
    



```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# 1. Calculate feature importances from your trained dt_model
importances = dt_model.feature_importances_
feature_names = X.columns
feat_imp_dict = dict(zip(feature_names, importances))

# 2. Categorize variables into the main fishbone branches
categories = {
    "Patient Demographics": ["age", "gender_Male", "bmi"],
    "Vital Signs": ["systolic_bp", "heart_rate"],
    "Lab Tests": ["bnp", "sodium", "creatinine"],
    "Prescribed Medications": ["ace_inhibitor", "beta_blocker", "diuretic"],
    "Social & Adherence Factors": ["adherence_score", "income_level_Low", "income_level_Medium", "distance_to_hospital_km"]
}

# 3. Initialize the plot canvas
plt.figure(figsize=(16, 10))
ax = plt.gca()
ax.set_facecolor('#f8f9fa')  # Clean soft background

# Draw the main backbone (central horizontal line)
plt.annotate('', xy=(10, 5), xytext=(1, 5),
             arrowprops=dict(arrowstyle="->", color='#0f4c5c', lw=5))

# Draw the Fish Head (The Problem Statement)
head_poly = plt.Polygon([[10, 5], [11.5, 6.2], [12, 5], [11.5, 3.8]], color='#2a9d8f')
ax.add_patch(head_poly)
plt.text(11.1, 5, "30-Day\nReadmission\n(Target)",
         ha='center', va='center', color='white', fontsize=12, fontweight='bold')

# Draw the Fish Tail
tail_poly = plt.Polygon([[1, 5], [0.2, 6.2], [0.5, 5], [0.2, 3.8]], color='#e76f51')
ax.add_patch(tail_poly)

# 4. Plot major branches and map features dynamically
up_x_positions = [3, 5.5, 8]      # Horizontal positions for upper bones
down_x_positions = [4.2, 7]       # Horizontal positions for lower bones

cat_keys = list(categories.keys())

# Plot Upper Bones
for i, x_pos in enumerate(up_x_positions):
    if i < len(cat_keys):
        cat_name = cat_keys[i]
        # Draw main diagonal branch line
        plt.plot([x_pos, x_pos + 1.2], [5, 7.5], color='#457b9d', lw=3)
        # Add category title box
        plt.text(x_pos + 1.2, 7.7, cat_name, ha='center', va='bottom', fontsize=11,
                 fontweight='bold', bbox=dict(boxstyle="round,pad=0.4", fc='#e1edd0', ec='#457b9d', lw=1.5))
       
        # Add sub-features along the bone based on their importance
        y_offset = 5.6
        for feat in categories[cat_name]:
            matching_feats = [f for f in feat_imp_dict if f.startswith(feat)]
            imp_val = sum([feat_imp_dict[mf] for mf in matching_feats]) if matching_feats else 0.0
           
            text_label = f"{feat.replace('_', ' ')} ({imp_val:.2%})"
            current_x = x_pos + ((y_offset - 5) * 1.2 / 2.5)
            plt.annotate('', xy=(current_x, y_offset), xytext=(current_x - 1, y_offset),
                         arrowprops=dict(arrowstyle="->", color='#6c757d', lw=1.5))
            plt.text(current_x - 1.05, y_offset + 0.05, text_label, ha='left', va='bottom', fontsize=9.5)
            y_offset += 0.6

# Plot Lower Bones
for i, x_pos in enumerate(down_x_positions):
    idx = i + 3  
    if idx < len(cat_keys):
        cat_name = cat_keys[idx]
        # Draw main diagonal branch line pointing downwards
        plt.plot([x_pos, x_pos + 1.2], [5, 2.5], color='#457b9d', lw=3)
        # Add category title box
        plt.text(x_pos + 1.2, 2.3, cat_name, ha='center', va='top', fontsize=11,
                 fontweight='bold', bbox=dict(boxstyle="round,pad=0.4", fc='#fceade', ec='#e76f51', lw=1.5))
       
        # Add sub-features along the bone
        y_offset = 4.4
        for feat in categories[cat_name]:
            matching_feats = [f for f in feat_imp_dict if f.startswith(feat)]
            imp_val = sum([feat_imp_dict[mf] for mf in matching_feats]) if matching_feats else 0.0
           
            text_label = f"{feat.replace('_', ' ')} ({imp_val:.2%})"
            current_x = x_pos + ((5 - y_offset) * 1.2 / 2.5)
            plt.annotate('', xy=(current_x, y_offset), xytext=(current_x - 1, y_offset),
                         arrowprops=dict(arrowstyle="->", color='#6c757d', lw=1.5))
            plt.text(current_x - 1.05, y_offset + 0.05, text_label, ha='left', va='bottom', fontsize=9.5)
            y_offset -= 0.6

# 5. Calculate metrics for the summary box
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)

# Add Model Performance Summary box
performance_text = (
    "📊 Decision Tree Performance:\n"
    f"• Accuracy: {accuracy:.2%}\n"
    f"• Precision: {precision:.2%}\n"
    f"• Recall: {recall:.2%}\n"
    f"• F1-Score: {f1:.2%}"
)
plt.text(12, 1.5, performance_text, ha='right', va='bottom', fontsize=11,
         bbox=dict(boxstyle="round,pad=0.6", fc='#ffffff', ec='#2a9d8f', lw=2))

# Final Layout Enhancements
plt.title("Ishikawa (Fishbone) Diagram of Heart Failure Readmission Causes\nBased on Decision Tree Feature Importances",
          fontsize=14, fontweight='bold', pad=20, color='#1d3557', ha='center')

plt.xlim(0, 13)
plt.ylim(1, 9)
plt.axis('off')  # Hide grid axes
plt.tight_layout()

# Save the final image to your current workspace directory
plt.savefig('fishbone_diagram_en.png', dpi=300)
plt.show()

```

    C:\ProgramData\Anaconda3\lib\site-packages\matplotlib\backends\backend_agg.py:240: RuntimeWarning: Glyph 128202 missing from current font.
      font.set_text(s, 0.0, flags=flags)
    C:\ProgramData\Anaconda3\lib\site-packages\matplotlib\backends\backend_agg.py:203: RuntimeWarning: Glyph 128202 missing from current font.
      font.set_text(s, 0, flags=flags)
    


    
![png](output_54_1.png)
    



```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# --- 1. Prepare Features and Target ---
# 'tree' is your DataFrame. We switch the target to 'readmitted_30d' to fix the error.
features = [col for col in tree.columns if col != 'readmitted_30d']
X = tree[features]
y = tree['readmitted_30d']

# --- 2. Split Dataset ---
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# --- 3. Initialize Decision Tree Model ---
# Kept as 'tree_model' so it doesn't overwrite your 'tree' dataset variable
tree_model = DecisionTreeClassifier(
    max_depth=None,
    min_samples_split=2,
    min_samples_leaf=1,
    random_state=42
)

# --- 4. Train Model ---
tree_model.fit(X_train, y_train)

# --- 5. Make Predictions and Evaluate ---
tree_pred = tree_model.predict(X_test)

print(f"Decision Tree Accuracy: {accuracy_score(y_test, tree_pred):.4f}")
print("\nClassification Report:")
print(classification_report(y_test, tree_pred, digits=4))

# --- 6. Plot Tree (First 3 levels for clean readability) ---
plt.figure(figsize=(20, 10))
plot_tree(
    tree_model,
    feature_names=features,
    class_names=['Not Readmitted', 'Readmitted'], # Correct target categories
    filled=True,
    max_depth=3
)
plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# --- 1. Clean Data & Convert Text Categories to Numbers ---
# Ensure unique identifier column is dropped
if 'patient_id' in tree.columns:
    tree = tree.drop(columns=['patient_id'])

# Handle missing numeric values automatically so it runs clean
tree = tree.fillna(tree.median(numeric_only=True))

# Convert text variables (gender, income_level) to numerical 0s and 1s
tree_encoded = pd.get_dummies(tree, drop_first=True)

# --- 2. Prepare Features and Target ---
# Using 'readmitted_30d' from your updated columns
features = [col for col in tree_encoded.columns if col != 'readmitted_30d']
X = tree_encoded[features].astype(float)
y = tree_encoded['readmitted_30d']

# --- 3. Split Dataset ---
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# --- 4. Initialize and Train Decision Tree Model ---
tree_model = DecisionTreeClassifier(
    max_depth=None,
    min_samples_split=2,
    min_samples_leaf=1,
    random_state=42
)
tree_model.fit(X_train, y_train)

# --- 5. Make Predictions and Evaluate ---
tree_pred = tree_model.predict(X_test)

print(f"Decision Tree Accuracy: {accuracy_score(y_test, tree_pred):.4f}")
print("\nClassification Report:")
print(classification_report(y_test, tree_pred, digits=4))

# --- 6. Plot Tree Diagram (First 3 levels for clean readability) ---
plt.figure(figsize=(20, 10))
plot_tree(
    tree_model,
    feature_names=features,
    class_names=['Not Readmitted', 'Readmitted'],
    filled=True,
    max_depth=3
)
plt.show()
```

    Decision Tree Accuracy: 0.5033
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0     0.6111    0.5588    0.5838       374
               1     0.3605    0.4115    0.3843       226
    
        accuracy                         0.5033       600
       macro avg     0.4858    0.4852    0.4840       600
    weighted avg     0.5167    0.5033    0.5087       600
    
    


    
![png](output_55_1.png)
    


    Decision Tree Accuracy: 0.5033
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0     0.6111    0.5588    0.5838       374
               1     0.3605    0.4115    0.3843       226
    
        accuracy                         0.5033       600
       macro avg     0.4858    0.4852    0.4840       600
    weighted avg     0.5167    0.5033    0.5087       600
    
    


    
![png](output_55_3.png)
    



```python

```
